import { fromEvent } from "rxjs";
import { map } from 'rxjs/operators';

// Creating an Observable from mouse clicks
const click$ = fromEvent<MouseEvent>(document, "click");

// Creating an Observable from pressed keys
const keyPressed$ = fromEvent<KeyboardEvent>(document, "keydown");

// Creating an Observable from scroll changes
const scroll$ = fromEvent<UIEvent>(document, "scroll");

// Creating an Observable from copy action
const copie$ = fromEvent<ClipboardEvent>(document, "copy");



click$.subscribe(click => console.log(click));
// Output: MouseEvent {isTrusted: true}

keyPressed$.pipe(map(({code}) => code)).subscribe(console.log);
// Output: KeyboardEvent {isTrusted: true}

scroll$.subscribe(scroll => console.log(scroll));
// Output: UIEvent {isTrusted: true}

copie$.subscribe(console.log);
// Output: ClipboardEvent {isTrusted: true}

