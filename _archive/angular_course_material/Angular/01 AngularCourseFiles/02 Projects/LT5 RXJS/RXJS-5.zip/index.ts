import { range } from "rxjs";

// Observable will emit a sequence of numbers from 0 to 4 and complete
const number$ = range(5);

// Observable will emit a sequence of numbers from 1 to 5 and complete
const range$ = range(1, 5);

// Observable will emit a sequence of 10 numbers starting at 10 (from 10 to 19)
const moreNumber$ = range(10, 10);


number$.subscribe(number => console.log(number));
// Output: 0, 1, 2, 3, 4

range$.subscribe(console.log);
// Output: 1, 2, 3, 4, 5

moreNumber$.subscribe(number => console.log(number));
// Output: 10, 11, 12, 13, 14, 15, 16, 17, 18, 19