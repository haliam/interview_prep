import { ajax } from "rxjs/ajax";
// We're going to use the ghibliapi, I'm a big fan

// Observable will emit the entire AjaxResponse object
const ghibliFilmsResponse$ = ajax("https://ghibliapi.herokuapp.com/films");

// Observable will only emit the response data
const ghibliFilm$ = ajax.getJSON("https://ghibliapi.herokuapp.com/films");

// What if we need custom headers? No problem!
const ghibliFilmWithHeaders$ = ajax({
  url: 'https://ghibliapi.herokuapp.com/films',
  method: 'GET',
  headers: {
    'Content-Type': 'json'
  },
  body: {
    message: "Custom message 'cause we're so cool"
  }
});



ghibliFilmsResponse$.subscribe(console.log);
// Output: AjaxResponse {xhr: {}, request: {}...}

ghibliFilm$.subscribe(films => console.log(films));
// Output: [Object, Object, Object...]

ghibliFilmWithHeaders$.subscribe(console.log);
// Output: AjaxResponse {xhr: {}, request: {}...}