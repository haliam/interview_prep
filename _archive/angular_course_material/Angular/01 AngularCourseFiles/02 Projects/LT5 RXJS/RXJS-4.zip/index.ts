import { interval } from 'rxjs';

// Observable will emit incremental numbers, one every second (1000ms)
const number$ = interval(1000);

// We didn't pass the interval size parameter, so default value is 0ms
const superFastNumber$ = interval();

number$.subscribe(console.log);
// Output: 0 1 2 3 4 5...

// Careful with this one, it will emit numbers very very quickly. Uncomment the following line to see it:
//superFastNumber$.subscribe(number => console.log(number));
// Output: O 1 2 3 4 5 6 7 8 9...
