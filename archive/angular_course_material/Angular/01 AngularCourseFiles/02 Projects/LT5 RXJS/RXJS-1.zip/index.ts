import { of } from 'rxjs'; 

// Creating an Observable from a string
const letter$ = of("RxJS is cool");

// Creating an Observable from an array of strings
const fruit$ = of(["Strawberry", "Cherry", "Blackberry"]);

// Creating an Observable from a Map object
const pokemon$ = of(
  new Map([
    ["Squirtle", "Water"],
    ["Charmander", "Fire"],
    ["Bulbasur", "Grass"]
  ])
);

// Creating an Observable from a promise
const promise$ = of(
  Promise.resolve("I promise to start learning RxJS")
);

// Creating an Observable from a nodeList
const node$ = of(document.querySelectorAll("p"));


letter$.subscribe(letter => console.log(letter));
// Output: "R","x","J","S"," ","i","s"," ","c","o","o","l"

fruit$.subscribe(console.log);
// Output: "Strawberry", "Cherry", "Blackberry"

pokemon$.subscribe(console.log);
// Output: ["Squirtle", "Water"], ["Charmander", "Fire"], ["Bulbasur", "Grass"]

promise$.subscribe(promise => console.log(promise));
// Output "I promise to start learning RxJS"

node$.subscribe(node => console.log(node));
/* Output: 
HTMLParagraphElement {tagName: "p", innerHTML: "Chocolate"...}
HTMLParagraphElement {tagName: "p", innerHTML: "Vanilla"...}
HTMLParagraphElement {tagName: "p", innerHTML: "Coconut"...}
*/
