import { fromFetch } from 'rxjs/fetch';
import { switchMap, catchError } from 'rxjs/operators';
import { of, throwError } from 'rxjs';

// This Observable will emit the entire Response object
const pokemonResponse$ = fromFetch('https://pokeapi.co/api/v2/pokemon/1');

pokemonResponse$.subscribe(console.log);
// Output: Response {}

// If we just want the data, we can do something like this
pokemonResponse$
  .pipe(switchMap((response) => response.json()))
  .subscribe(console.log);
// [Object, Object, Object...]

// What about error handling? Here's an example
const ghibliFilmError$ = fromFetch(
  'https://ghibliapi.herokuapp.com/wrongURL'
).pipe(
  switchMap((response) => {
    if (!response.ok) {
      throw `There was an error with status ${response.status}`;
    }
    return response.json();
  }),
  catchError((err) => {
    console.error(err);
    return of({ error: true, message: err });
  })
);

ghibliFilmError$.subscribe((result) => console.log(result));
// Output: {error: true, message: "There was an error with status 404"}
