import { generate } from "rxjs";

// This Observable will emit numbers from 1 to 9
const number$ = generate(
  1,
  x => x < 10,
  x => x + 1
);

number$.subscribe(console.log);
// Output: 1, 2, 3, 4, 5, 6, 7, 8, 9

// If you find the previous syntax a little confusing, you can provide
// an object instead. This Observable will emit the even numbers from 2 to 10
const evenNumber$ = generate({
  initialState: 2,
  condition: x => x <= 10,
  iterate: x => x + 2
});

evenNumber$.subscribe(number => console.log(number));
// Output: 2, 4, 6, 8, 10


// WARNING: This will generate an endless loop
const endles$ = generate({ initialState: 1, iterate: x => +1 });

// Uncomment at your own risk 
//endles$.subscribe(console.log);
