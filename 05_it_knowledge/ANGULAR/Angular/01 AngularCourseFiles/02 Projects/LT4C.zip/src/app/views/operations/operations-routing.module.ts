import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { OperationsComponent } from "./operations.component";
import { ItemComponent } from "./item.component";
import { NewComponent } from "./new.component";

const routes: Routes = [
  {
    path: "",
    component: OperationsComponent
  },
  {
    path: ":id",
    component: ItemComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OperationsRoutingModule { }
